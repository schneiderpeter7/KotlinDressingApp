package com.pet.dressing

import retrofit2.Call
import retrofit2.http.GET

interface Api {
    @GET("dressing.json")
    fun loadDressing(): Call<List<DressingDTO>>
}