package com.pet.dressing

import android.app.Application

class DressingApp: Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLokator.provide(this)
    }

}