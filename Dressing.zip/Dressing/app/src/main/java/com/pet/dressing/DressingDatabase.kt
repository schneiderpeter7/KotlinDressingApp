package com.pet.dressing

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(version = 2, entities = [DressingEntity::class])
@TypeConverters(ListStringConverter::class)
abstract class DressingDatabase:RoomDatabase() {
    companion object{
        fun buildDatabase(context: Context)=
            Room.databaseBuilder(context,DressingDatabase::class.java,"dressing_db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build()
    }
abstract fun dressingDao():DressingDao
}