package com.pet.dressing

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.TypeConverters

@Entity(tableName = "dressing")
data class DressingEntity(
    @PrimaryKey val id: Long,
    val dressingName: String?,
    val calories: Int?,
    val carbs: Int?,
    @TypeConverters(ListStringConverter::class) val restaurantNames: List<String>

)
@Dao
interface DressingDao{
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(vararg data:DressingEntity)

    @Query("Select * from dressing ORDER BY id DESC")
    fun getAll(): List<DressingEntity>

    @Query("Select * from dressing WHERE id = :id")
    fun get(id: Long): DressingEntity?
}
