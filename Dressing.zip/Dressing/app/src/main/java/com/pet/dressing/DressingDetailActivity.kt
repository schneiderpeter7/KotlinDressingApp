package com.pet.dressing

import android.app.Activity
import android.os.Bundle
import com.pet.dressing.databinding.ActivityDetailBinding
import com.pet.dressing.databinding.ActivityDressingBinding

class DressingDetailActivity:Activity() {
    lateinit var binding:ActivityDetailBinding

    val dao by lazy { ServiceLokator.provideDressingDao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val dressingId=intent.getLongExtra("dressing_id",-1)
        dao.get(dressingId)?.let {
            val restaurantNames= it.restaurantNames.joinToString(",")
            binding.restaurantname.text=restaurantNames
        }?:kotlin.run {
            binding.restaurantname.text="Dressing Not Found"
        }
    }

}