package com.pet.dressing

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.pet.dressing.databinding.ActivityDetailBinding
import com.pet.dressing.databinding.ActivityDressingBinding
import com.pet.dressing.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    private val dressing by lazy { ServiceLokator.provideDressingDao().getAll() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.edit.setOnClickListener {
            startActivity(Intent(this,DressingNetworkActivity::class.java))
        }
        binding.network.setOnClickListener {
            startActivity(Intent(this, DressingNetworkActivity::class.java))
        }
    }
}