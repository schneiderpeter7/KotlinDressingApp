package com.pet.dressing

interface IDressingNetworkPresenter {
    var view: IDressingNetworkView?
    fun getDressing()
}
interface IDressingNetworkView{
    fun showerror(msg:String)
    fun submitlist(list: List<DressingEntity>)
}