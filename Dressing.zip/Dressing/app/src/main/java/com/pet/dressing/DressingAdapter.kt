package com.pet.dressing

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.pet.dressing.databinding.RowDressingBinding

class DressingAdapter (
    val onItemClicked:(Long)->Unit,
    )  :RecyclerView.Adapter<DressingAdapter.DressingViewHolder>() {
    private var dressing : List<DressingEntity> = listOf()
    class DressingViewHolder(val binding: RowDressingBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DressingViewHolder {
        return DressingViewHolder(
            RowDressingBinding.inflate(
                LayoutInflater.from(parent.context),parent,false
            )
        )
    }

    override fun getItemCount(): Int =dressing.size
    override fun onBindViewHolder(holder: DressingViewHolder, position: Int) {
        val dressing=dressing[position]
        holder.binding.name.text=dressing.dressingName
        holder.binding.kcal.text=dressing.calories.toString()
        holder.binding.carbs.text=dressing.carbs.toString()
        holder.binding.root.setOnClickListener {
            onItemClicked(dressing.id)
        }

    }
    fun submitList(data:List<DressingEntity>) {
        this.dressing=data
        notifyDataSetChanged()
    }
    fun View.visible(visible: Boolean) {
        visibility=if (visible) View.VISIBLE else View.GONE
    }
}