package com.pet.dressing

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import com.pet.dressing.databinding.ActivityDressingBinding

class DressingActivity :Activity() {

    private lateinit var binding: ActivityDressingBinding
    private lateinit var adapter: DressingAdapter
    private val dressingdao by lazy { ServiceLokator.provideDressingDao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityDressingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.recyclerView.adapter=DressingAdapter(
            onItemClicked = {
                startActivity(Intent(this,DressingActivity::class.java).apply {
                  putExtra("dressing_id",it)
                })
            }
        )
        binding.recyclerView.layoutManager=
            LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
    }
}