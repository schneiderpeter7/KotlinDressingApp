package com.pet.dressing

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.pet.dressing.databinding.ActivityDressingBinding
import com.pet.dressing.databinding.RowDressingBinding

class DressingNetworkActivity : Activity(),IDressingNetworkView {
    private lateinit var binding: ActivityDressingBinding
    private lateinit var adapter: DressingAdapter
    private var presenter :IDressingNetworkPresenter = DressingNetworkPresenter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityDressingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.apply {

        }
        binding.recyclerView.adapter=DressingAdapter(
            onItemClicked = {
                startActivity(Intent(this,DressingDetailActivity::class.java).apply {
                    putExtra("dressing_id",it)
                })
            },
        ).also {
            adapter=it
            presenter.getDressing()
        }
        binding.recyclerView.layoutManager=LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
    }

    override fun onStart() {
        super.onStart()
        presenter.view=this
    }

    override fun onStop() {
        super.onStop()
        presenter.view=null
    }

    override fun showerror(msg: String) {
        binding.recyclerView.visibility=View.GONE
        binding.error.text=msg
        binding.error.visibility=View.VISIBLE
    }
    override fun submitlist(list: List<DressingEntity>) {
        adapter.submitList(list)
    }
}
fun DressingDTO.convertToEntity():DressingEntity{
    return DressingEntity(id,dressingName,calories,carbs,restaurantNames)
}