package com.pet.dressing

data class DressingDTO(
    val id:Long,
    val dressingName:String,
    val calories: Int,
    val carbs: Int,
    val restaurantNames: List<String>
)