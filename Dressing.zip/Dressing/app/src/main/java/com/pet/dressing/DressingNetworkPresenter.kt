package com.pet.dressing

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DressingNetworkPresenter: IDressingNetworkPresenter {
    private val api by lazy { ServiceLokator.provideapi() }
    private  val dao by lazy { ServiceLokator.provideDressingDao() }

    override var view: IDressingNetworkView?=null

    override fun getDressing() {
        api.loadDressing().enqueue(object : Callback<List<DressingDTO>>{
            override fun onResponse(call: Call<List<DressingDTO>>, response: Response<List<DressingDTO>>) {
                if (response.isSuccessful){
                    val dressing=response.body()
                    val entities= dressing.orEmpty().map { it.convertToEntity() }
                    saveDressingToDb(entities)
                    view?.submitlist(entities)
                }else{
                    view?.showerror(response.message())
                }

            }

            override fun onFailure(call: Call<List<DressingDTO>>, t: Throwable) {
                view?.showerror(t.message?:"Error")
            }
        })

    }
    private fun saveDressingToDb(entities: List<DressingEntity>) {
        dao.insert(*entities.toTypedArray())
    }
}