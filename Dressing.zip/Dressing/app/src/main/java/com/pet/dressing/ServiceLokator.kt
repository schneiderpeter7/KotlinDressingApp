package com.pet.dressing

import android.content.Context

object ServiceLokator {

    private lateinit var db:DressingDatabase
    private val dressingDao: DressingDao by lazy { db.dressingDao() }
    private val api : Api by lazy { Network().api() }

    fun provideDressingDao()= dressingDao
    fun provideapi()= api

    fun provide(context: Context){
        db=DressingDatabase.buildDatabase(context)
    }
}